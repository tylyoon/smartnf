"use strict";
(() => {
  const root = document.getElementById('fn-results');
  if (!root) return;
  const $ = id => document.getElementById(id);
  const C=window.SmartNFFoodCategories;
  const labels = {energy:'열량',carbohydrate:'탄수화물',protein:'단백질',fat:'지방',sugars:'당류',fiber:'식이섬유',sodium:'나트륨',potassium:'칼륨',phosphorus:'인',saturated_fat:'포화지방',trans_fat:'트랜스지방',cholesterol:'콜레스테롤',calcium:'칼슘',iron:'철',vitamin_c:'비타민 C',vitamin_d:'비타민 D',vitamin_b12:'비타민 B12'};
  const statuses = {blank:'자료 없음',unmeasured:'미측정',trace:'미량 (Tr)',invalid:'원문 확인 필요',quoted_or_calculated:'인용·산출값',numeric:'원본 수치'};
  const state = {manifest:null,source:'rda_10_4',index:[],filtered:[],page:0,selected:null,category:'',load:0,detail:0};
  let requestedId = new URLSearchParams(location.search).get('food');
  if(requestedId && !/^(rda_10_4|mfds_dishes):[A-Za-z0-9_-]{1,80}$/.test(requestedId))requestedId=null;
  if(requestedId)state.source=requestedId.split(':')[0];
  document.querySelectorAll('[data-source]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.source===state.source)));
  const cache = new Map();
  const pageSize = 20;
  const norm = text => String(text || '').normalize('NFKC').replace(/\s+/g,'').toLowerCase();
  function el(tag,text,cls) { const node=document.createElement(tag); if(text!==undefined) node.textContent=String(text); if(cls)node.className=cls; return node; }
  function basis(text) { return text === '100g edible portion' ? '가식부 100g (먹을 수 있는 부분)' : String(text); }
  function basisType(text) { return /100\s*m[lL]/i.test(text) ? 'ml' : /100\s*g/i.test(text) ? 'g' : ''; }
  async function json(path) { const response=await fetch(path,{credentials:'same-origin'});if(!response.ok)throw new Error('DATA_UNAVAILABLE');return response.json(); }
  function dataUrl(file) {
    if (!/^[a-z0-9_-]+\.json$/.test(file) || !/^v-[a-f0-9]{20}$/.test(state.manifest.version)) throw new Error('INVALID_DATA_PATH');
    return '/js/data/food-nutrition/'+state.manifest.version+'/'+file;
  }
  function status(text) {$('fn-status').textContent=text;}
  function resetDetail() {
    state.detail++;state.selected=null;
    $('fn-detail-heading').textContent='식품을 선택해 주세요';
    $('fn-detail').querySelector('.fn-muted').textContent='목록에서 식품을 선택하면 영양성분과 출처를 확인할 수 있습니다.';
    $('fn-detail-body').replaceChildren();
  }
  async function loadSource() {
    const token=++state.load;state.category='';$('fn-classification').hidden=true;state.index=[];state.filtered=[];state.page=0;resetDetail();
    $('fn-retry').hidden=true;status('자료를 불러오고 있습니다.');render();
    try {
      const indexes=await Promise.all(['rda_10_4','mfds_dishes'].map(async source=>{const meta=state.manifest.sources[source],key=dataUrl(meta.index);if(!cache.has(key))cache.set(key,json(key).catch(error=>{cache.delete(key);throw error;}));const rows=await cache.get(key);if(!Array.isArray(rows)||rows.length!==meta.count)throw Error('INVALID_INDEX');return rows;}));
      if(token!==state.load)return;
      const I=window.SmartNFFoodIdentity,all=indexes.flat();
      if(requestedId){const requested=all.find(r=>r.id===requestedId);if(requested){state.source=I.kind(requested)==='ingredient'?'rda_10_4':'mfds_dishes';document.querySelectorAll('[data-source]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.source===state.source)));}}
      const rows=all.filter(row=>state.source==='rda_10_4'?I.kind(row)==='ingredient':I.kind(row)!=='ingredient').map(row=>({...row,group:state.source==='mfds_dishes'&&row.id.startsWith('rda_10_4:')?(I.kind(row)==='dish'?'조리된 식재료':'분류 확인 필요'):row.group}));
      state.index=rows;
      populateGroups();
      $('fn-classification').hidden=false;$('fn-group-label').hidden=!!C;
      $('fn-source-note').textContent=(state.source==='rda_10_4'?'생것과 조리용 가공 재료만 표시합니다. 구이·삶기 등 조리된 항목은 음식에서 조회합니다.':'조리·가공 음식과 분류 확인이 필요한 자료입니다. 원본 제공처와 표시 기준은 상세에서 확인하세요.')+' · '+rows.length.toLocaleString('ko-KR')+'건';
      filter();
      if(requestedId){const row=rows.find(r=>r.id===requestedId);requestedId=null;if(row){state.filtered=[row];render();status('선택한 식품의 성분과 출처를 보여드립니다.');detail(row);}else status('선택한 식품 자료를 찾지 못했습니다. 이름으로 다시 검색해 주세요.');}
    } catch(error) {if(token!==state.load)return;status('자료를 불러오지 못했습니다. 화면 데이터 준비와 서버 실행 상태를 확인해 주세요.');$('fn-retry').hidden=false;}
  }
  function populateGroups(){
    const previous=$('fn-group').value;$('fn-group').replaceChildren(el('option','전체 세부 분류'));$('fn-group').firstChild.value='';
    [...new Set(state.index.filter(r=>!C||C.includes(state.source,state.category,r.group)).map(r=>r.group))].sort((a,b)=>a.localeCompare(b,'ko')).forEach(group=>{const option=el('option',group);option.value=group;$('fn-group').append(option);});
    if([...$('fn-group').options].some(o=>o.value===previous))$('fn-group').value=previous;
  }
  function chooseCategory(id){state.category=state.category===id?'':id;$('fn-group').value='';populateGroups();resetDetail();filter();}
  function renderCategories(){
    if(!C||!state.index.length)return;const A=window.SmartNFAllergy,profile=A?.profile(),all=state.index,allowed=all.filter(row=>!A||A.inspect(row,profile).allowed);
    const grid=$('fn-categories');grid.replaceChildren();const definitions=[['','🔎','전체',[]],...C.groups(state.source)];
    definitions.forEach(([id,icon,title])=>{const total=all.filter(row=>C.includes(state.source,id,row.group)).length;if(!total&&id)return;const count=allowed.filter(row=>C.includes(state.source,id,row.group)).length;
      const button=el('button');button.type='button';button.dataset.category=id;button.setAttribute('aria-pressed',String(state.category===id));button.setAttribute('aria-controls','fn-results');const picture=C.icon(id);picture.setAttribute('aria-hidden','true');button.append(picture,el('strong',title),el('small',count===total?count.toLocaleString('ko-KR')+'개':count.toLocaleString('ko-KR')+'개 조회 가능 / 원본 '+total.toLocaleString('ko-KR')+'개'));button.addEventListener('click',()=>chooseCategory(id));grid.append(button);
    });
    const subs=$('fn-subgroups');subs.replaceChildren();if(state.category){const scoped=all.filter(r=>C.includes(state.source,state.category,r.group));const groups=[...new Set(scoped.map(r=>r.group))].sort((a,b)=>a.localeCompare(b,'ko'));
      for(const group of ['',...groups]){const count=allowed.filter(r=>C.includes(state.source,state.category,r.group)&&(!group||r.group===group)).length;const button=el('button',(group||'전체 세부 분류')+' · '+count.toLocaleString('ko-KR'));button.type='button';button.dataset.subgroup=group;button.setAttribute('aria-pressed',String($('fn-group').value===group));button.addEventListener('click',()=>{$('fn-group').value=$('fn-group').value===group?'':group;resetDetail();filter();});subs.append(button);}
    }
    const category=C.groups(state.source).find(x=>x[0]===state.category)?.[2]||'전체';$('fn-browse-context').textContent=(state.source==='rda_10_4'?'식재료':'음식')+' › '+category+($('fn-group').value?' › '+$('fn-group').value:'');$('fn-category-note').textContent='큰 분류를 누르면 세부 분류를 볼 수 있습니다. 숫자는 검색어·표시 기준 적용 전이며 알레르기 제외 조건은 반영합니다. 같은 버튼을 다시 누르면 분류를 해제합니다.';
    $('fn-query').placeholder=state.category?category+' 안에서 이름 검색':'예: 두부, 양파, 닭고기 가슴살';$('fn-search-wide').hidden=!state.category&&!$('fn-group').value;
  }
  function filter() {
    const words=$('fn-query').value.trim().split(/\s+/).filter(Boolean).map(norm);
    const I=window.SmartNFFoodIdentity,exactPrimary=state.source==='rda_10_4'&&I?I.primarySearch(state.index,words):null;
    const matched=state.index.filter(row=>(!C||C.includes(state.source,state.category,row.group))&&(I?I.matches(row,words,exactPrimary):words.every(word=>norm(row.name).includes(word)))&&(!$('fn-group').value||row.group===$('fn-group').value)&&(!$('fn-basis').value||basisType(row.basis)===$('fn-basis').value));
    const A=window.SmartNFAllergy,profile=A?.profile();state.filtered=matched.filter(row=>!A||A.inspect(row,profile).allowed);
    state.page=0;if(state.selected&&!state.filtered.some(r=>r.id===state.selected))resetDetail();renderCategories();render();status(state.filtered.length.toLocaleString('ko-KR')+'건을 찾았습니다.'+(exactPrimary?' ‘'+I.primary(matched[0]||{name:$('fn-query').value.split(/\s/)[0]})+'’ 재료명 기준 · 품종·부위 포함 · 조리 음식 제외.':'')+(A&&['has','review'].includes(A.profile().mode)?' 알레르기 일치·원재료 미확인 '+(matched.length-state.filtered.length).toLocaleString('ko-KR')+'건 제외.':''));
  }
  function render() {
    root.replaceChildren();
    const count=state.filtered.length;const pages=Math.ceil(count/pageSize);
    $('fn-result-count').textContent=count.toLocaleString('ko-KR')+'건';$('fn-empty').hidden=!!count;
    $('fn-page').textContent=pages ? (state.page+1)+' / '+pages : '0 / 0';
    $('fn-prev').disabled=state.page===0;$('fn-next').disabled=(state.page+1)*pageSize>=count;
    state.filtered.slice(state.page*pageSize,(state.page+1)*pageSize).forEach(row=>{
      const li=el('li');const button=el('button');button.type='button';button.dataset.foodId=row.id;
      button.setAttribute('aria-pressed',String(row.id===state.selected));
      button.append(el('strong',row.name),el('span',window.SmartNFFoodIdentity.stateLabel[window.SmartNFFoodIdentity.foodState(row)]+' · '+row.group+' · '+basis(row.basis)),el('small',row.id.split(':').slice(1).join(':')));
      button.addEventListener('click',()=>{if(state.selected===row.id){resetDetail();render();}else detail(row);});li.append(button);root.append(li);
    });
  }
  async function detail(row) {
    const token=++state.detail;state.selected=row.id;render();
    $('fn-detail-heading').textContent=row.name;$('fn-detail').querySelector('.fn-muted').textContent='상세정보를 불러오고 있습니다.';$('fn-detail-body').replaceChildren();
    try {
      const key=dataUrl(row.chunk);
      if(!cache.has(key))cache.set(key,json(key).catch(error=>{cache.delete(key);throw error;}));
      const chunk=await cache.get(key);if(token!==state.detail)return;
      const record=chunk[row.id];if(!record||record.id!==row.id)throw new Error('DETAIL_NOT_FOUND');
      const body=$('fn-detail-body');
      $('fn-detail').querySelector('.fn-muted').textContent=record.group+' · '+basis(record.basis_raw);
      const badges=el('div',undefined,'fn-badges');badges.append(el('span',window.SmartNFFoodIdentity.stateLabel[window.SmartNFFoodIdentity.foodState(record)]));badges.append(el('span','기준 '+basis(record.basis_raw)),el('span','식품코드 '+record.source_code));body.append(badges);
      if(window.SmartNFFoodFlow){const flow=window.SmartNFFoodFlow;const button=el('button',flow.selection().items.some(x=>x.id===record.id)?'✓ 선택됨 · 해제':'나의 선택에 담기','fc-primary');button.type='button';const registrationBadge=el('small','확정 등록됨 · 임시 연동');registrationBadge.dataset.registrationBadge=record.id;registrationBadge.hidden=!window.SmartNFFoodRegistration?.has(record.id);body.append(registrationBadge);button.dataset.foodSelect=record.id;button.dataset.selected=String(flow.selection().items.some(x=>x.id===record.id));button.setAttribute('aria-pressed',button.dataset.selected);const allergy=window.SmartNFAllergy?.inspect(record);if(allergy&&!allergy.allowed){button.disabled=true;button.textContent='현재 알레르기 조건에서 제외';body.append(el('p',allergy.reason,'fa-filter-note'));}button.addEventListener('click',()=>{try{const selected=flow.toggle(record,'manual',[]);flow.message(selected?'선택 목록에 담았습니다. 다시 누르면 해제됩니다.':'선택을 해제했습니다.');}catch(error){flow.message(error.message);}});body.append(button);}
      if(record.portion_raw)body.append(el('p','식품중량 원문: '+record.portion_raw+' · 1인분 확정값이 아니며 아래 영양값의 기준량과 구분해 주세요.','fn-muted'));
      const grid=el('dl',undefined,'fn-nutrients');
      Object.entries(labels).forEach(([key,label])=>{
        const item=record.nutrients[key];const tile=el('div');tile.append(el('dt',label));
        const kind=item?.status||'blank';
        const value=kind==='numeric'||kind==='quoted_or_calculated' ? String(item.raw)+' '+(item.unit||'') : statuses[kind]||'원문 확인 필요';
        tile.append(el('dd',value),el('small',statuses[kind]||kind));grid.append(tile);
      });body.append(grid);
      const missing=Object.values(record.nutrients).filter(x=>!['numeric','quoted_or_calculated'].includes(x.status)).length;body.append(el('p','영양항목 '+Object.keys(labels).length+'개 중 일반 수치·인용값 외 '+missing+'개 · 자료 없음·미측정·미량은 0이 아닙니다.','fn-small-note'));
      body.append(el('p','기준량에 대한 원본 값입니다. 실제 섭취량으로 환산하거나 개인 권장량으로 판정하지 않습니다.','fn-small-note'));
      const source=el('details');source.open=true;source.append(el('summary','자료 출처와 기준 확인'));
      const dl=el('dl',undefined,'fn-provenance');
      const entries=[['제공 자료',state.manifest.sources[record.id.split(':')[0]].publisher],['원본 출처',record.source_attribution||'미기재'],['시트',record.source_sheet],['원본 행',record.excel_row],['표시 기준',basis(record.basis_raw)]];
      const metaLabels={index:'자료 순번',version:'성분표 버전',state_description:'식품 상태 원문'};
      Object.entries(record.source_metadata||{}).forEach(([key,value])=>entries.push([metaLabels[key]||key,String(value)]));
      entries.forEach(([key,value])=>{dl.append(el('dt',key),el('dd',value??'미기재'));});source.append(dl);body.append(source);
      if(window.matchMedia('(max-width: 760px)').matches){$('fn-detail').scrollIntoView({block:'start',behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth'});$('fn-detail').focus({preventScroll:true});}
    } catch(error) {if(token!==state.detail)return;$('fn-detail').querySelector('.fn-muted').textContent='상세정보를 불러오지 못했습니다. 목록에서 다시 선택해 주세요.';}
  }
  document.querySelectorAll('[data-source]').forEach(button=>button.addEventListener('click',()=>{
    if(button.dataset.source===state.source)return;state.source=button.dataset.source;
    document.querySelectorAll('[data-source]').forEach(b=>b.setAttribute('aria-pressed',String(b===button)));
    $('fn-basis').value='';$('fn-group').value='';loadSource();
  }));
  let timer;
  $('fn-query').addEventListener('input',()=>{clearTimeout(timer);timer=setTimeout(filter,180);});
  $('fn-group').addEventListener('change',()=>{resetDetail();filter();});$('fn-search-wide').addEventListener('click',()=>{state.category='';$('fn-group').value='';populateGroups();resetDetail();filter();});$('fn-basis').addEventListener('change',filter);
  $('fn-search-form').addEventListener('submit',event=>{event.preventDefault();clearTimeout(timer);filter();});
  $('fn-prev').addEventListener('click',()=>{if(state.page>0){state.page--;render();}});
  $('fn-next').addEventListener('click',()=>{if((state.page+1)*pageSize<state.filtered.length){state.page++;render();}});
  async function init() {try{state.manifest=await json('/js/data/food-nutrition/manifest.json');await loadSource();}catch(error){status('식품 자료가 아직 준비되지 않았습니다. 화면 데이터 준비 후 다시 불러와 주세요.');$('fn-retry').hidden=false;}}
  window.addEventListener('smartnf-allergy-change',()=>{resetDetail();filter();});
  window.addEventListener('smartnf-food-selection',()=>{const flow=window.SmartNFFoodFlow;if(flow)document.querySelectorAll('[data-food-select]').forEach(button=>{if(button.disabled)return;const selected=flow.selection().items.some(x=>x.id===button.dataset.foodSelect);button.textContent=selected?'✓ 선택됨 · 해제':'나의 선택에 담기';button.dataset.selected=String(selected);button.setAttribute('aria-pressed',String(selected));});});
  window.addEventListener('smartnf-draft-inputs-reset',()=>{if(state.index.length)filter();});$('fn-retry').addEventListener('click',init);init();
})();
