'use strict';
(()=>{
 if(window.SmartNFDraftState)return;
 const KEY='smartnf.food-selection.v1';let reload=false,resetFailed=false;
 try{reload=performance.getEntriesByType('navigation')[0]?.type==='reload';if(!performance.getEntriesByType('navigation').length)reload=performance.navigation?.type===1;}catch{}
 if(reload){try{const raw=sessionStorage.getItem(KEY);if(raw){const value=JSON.parse(raw);if(value&&Array.isArray(value.items)&&value.items.length){value.items=[];sessionStorage.setItem(KEY,JSON.stringify(value));}}}catch{resetFailed=true;}}
 // Only draft forms present in this document are reset; never clear all storage or account forms.
 const controls=reload?[...document.querySelectorAll('#health-state-form input,#health-state-form textarea,#health-state-form select,#fn-search-form input,#fn-search-form select,#fc-search input,#fc-search select')].filter(node=>{
  if(['hidden','button','submit','reset'].includes(node.type)||node.hasAttribute('data-preserve-on-reload'))return false;
  const label=node.closest('label')||[...document.querySelectorAll('label')].find(l=>node.id&&l.htmlFor===node.id);
  return !(/allerg/i.test((node.name||'')+' '+(node.id||''))||/알레르기/.test(label?.textContent||''));
 }):[];
 function resetInputs(){for(const node of controls){if(node.dataset.healthConfirmed==='true')continue;if(node.tagName==='SELECT'){const options=[...node.options];node.selectedIndex=Math.max(0,options.findIndex(o=>o.defaultSelected));}else if(['checkbox','radio'].includes(node.type))node.checked=node.defaultChecked;else node.value=node.defaultValue;}}
 resetInputs();
 window.SmartNFDraftState={isReload:reload,get resetFailed(){return resetFailed;},draftSaved(){resetFailed=false;}};
 window.addEventListener('pageshow',event=>{if(event.persisted){window.dispatchEvent(new Event('smartnf-food-selection'));window.dispatchEvent(new Event('smartnf-food-registration'));}if(reload&&!event.persisted){resetInputs();window.dispatchEvent(new Event('smartnf-draft-inputs-reset'));}});
 document.addEventListener('DOMContentLoaded',()=>{if(resetFailed)document.querySelectorAll('[data-flow-status]').forEach(node=>node.textContent='임시 선택을 초기화하는 중 저장소 접근에 실패했습니다. 이전 선택은 표시하지 않으며, 저장 설정 확인 후 다시 선택해 주세요.');});
})();
